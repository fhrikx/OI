#include<bits/stdc++.h>
#define N 120000
using namespace std;
long long a[N];
long long b[N];
long long ans=0;
long long n;
int main(){
	freopen("1.in","r",stdin);
	freopen("1.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n/i;j++){
			a[j*i]++;
		}
	}
	for(int i=1;i<=n;i++)b[i]=b[i-1]+a[i-1];
	for(int i=1;i<=n;i++)ans+=b[i];
	printf("%lld\n",n*n*n-ans);
}
