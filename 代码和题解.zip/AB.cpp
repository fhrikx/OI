#include<bits/stdc++.h>
using namespace std;
long long A,P;
long long phi(int x){
	int ans=1;
	for(int i=2;i*i<=x;i++){
		if(x%i==0)ans*=(x-1);
		while(x%i==0)x/=i;
	}
	return ans*max(x-1,1);
}
long long power(long long x,long long k,long long P){
	long long ans=1;
	x%=P;
	while(k){
		if(k&1)(ans*=x)%=P;
		(x*=x)%=P;
		k>>=1;
	}
	return ans;
}
int main(){
	freopen("AB10.in","r",stdin);
	freopen("AB10.out","w",stdout);
	scanf("%lld%lld",&A,&P);
	printf("%lld %lld\n",A,P);
	return 0;
	long long B=2;
	while(1){
		B++;
		if(A==B)continue;
		if(power(B,A,P)==power(A,B,P)){
			printf("%lld\n",B);
			return 0; 
		}
	}
} 
